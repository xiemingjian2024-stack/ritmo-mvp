# exercises-dataset data attribution

Imported non-media data originates from [hasaneyldrm/exercises-dataset](https://github.com/hasaneyldrm/exercises-dataset), commit `7455efae41b330c265e7cd4b78dfa848e7ce5ebd`.

Copyright (c) 2026 Hasan Emir Yıldırım. The source project's MIT license covers its code, dataset structure, and non-media text/translations. The generated `exercises-dataset.json` contains only transformed non-media fields. It does **not** contain image files, GIF files, URLs that the application can load, or any grant to use Gym visual media. `media.sourceRef` is provenance metadata only and `media.authorization` remains `not_licensed`.

MIT License:

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation and data files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Media exclusion: source `images/` and `videos/` remain © Gym visual and require separate permission; see the [source LICENSE](https://github.com/hasaneyldrm/exercises-dataset/blob/main/LICENSE) and [NOTICE](https://github.com/hasaneyldrm/exercises-dataset/blob/main/NOTICE.md).
