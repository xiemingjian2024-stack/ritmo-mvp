# RITMO · Interaction Demo V1.3

## Run locally

```bash
cd /Users/xiemingjian/.codex/.chatgpt-projects/g-p-6a9e2a863a8c8191b0b3397eb607de72/interaction-demo-v1
PATH=/Users/xiemingjian/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin:/Users/xiemingjian/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback:$PATH pnpm dev --host 0.0.0.0 --port 4173 --strictPort
```

Open `http://localhost:4173/`.

## Demo entry points

- Training execution: `http://localhost:4173/?flow=training`
- Plan creation: `http://localhost:4173/?flow=plans`
- Training records: `http://localhost:4173/?flow=records`

## Review paths

1. Training: start the current cycle plan, a recommended temporary workout, or a custom temporary workout → let the simulated rhythm advance → Rest → adjust the next set → manually start the next exercise after 3-2-1 → complete the workout and confirm a session is saved.
2. Plans: open Create Plan → apply a recommendation directly or inspect it first → create/edit a plan → add exercises across muscle groups → save → add plans to the cycle → reorder while keeping NEXT stable.
3. Records: switch front/back or tap a muscle → inspect recency calculated from completed sessions → select a historical date below the overview → confirm all sessions on that date are listed. Future dates are disabled.

## Scope notes

- Data is persisted locally under `ritmo-demo-v3`; there is no backend or cloud sync. Existing V3 data is migrated by adding missing session fields without clearing plans or environments.
- Rep progression and rest timing are accelerated for review and do not represent sensor-based rep detection.
- Completed sessions are immutable snapshots. Editing or deleting a plan does not rewrite past records.
- Only completed cycle-plan workouts advance NEXT. Recommended/custom temporary workouts and cancelled workouts do not.
- The review routes are separated by URL; there is no evaluation switcher inside the product UI.
- The 2.5D body uses the existing segmented SVG assets and always represents the latest state as of today. Historical date selection only filters the daily record.
- The plan home starts with four cycle plans and two independent plans so the grouped layout can be reviewed with representative content.
